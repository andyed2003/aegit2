#ifndef TEMPERATURE_IMPL_H
#define TEMPERATURE_IMPL_H
void TEMPERATURE_IMPL();
void __SLEEP(int period);
#endif


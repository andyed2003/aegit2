#ifndef AAAA_TEMPERATURE_IMPL_H
#define AAAA_TEMPERATURE_IMPL_H
void AAAA_TEMPERATURE_IMPL();
void __SLEEP(int period);
#endif


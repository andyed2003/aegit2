#ifndef AAAA_CONTROL_LOOP_IMPL_H
#define AAAA_CONTROL_LOOP_IMPL_H
void AAAA_CONTROL_LOOP_IMPL();
void __SLEEP(int period);
#endif


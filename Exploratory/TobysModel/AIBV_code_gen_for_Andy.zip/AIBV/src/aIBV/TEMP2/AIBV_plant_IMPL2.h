#ifndef AIBV_PLANT_IMPL2_H
#define AIBV_PLANT_IMPL2_H
void AIBV_plant_IMPL_AIBV_temperature_measurement(int *temperature);
void AIBV_plant_IMPL2();
#endif


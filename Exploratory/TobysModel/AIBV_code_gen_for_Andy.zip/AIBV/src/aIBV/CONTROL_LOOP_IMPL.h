#ifndef CONTROL_LOOP_IMPL_H
#define CONTROL_LOOP_IMPL_H
void CONTROL_LOOP_IMPL();
void __SLEEP(int period);
#endif

